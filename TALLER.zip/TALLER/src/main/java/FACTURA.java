/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class FACTURA {
    private String producto;
    private int cant;
    private int codigo;
    private double metodo_pago;
    private double total;

    public FACTURA(String producto, int cant, int codigo, double metodo_pago, double total) {
        this.producto = producto;
        this.cant = cant;
        this.codigo = codigo;
        this.metodo_pago = metodo_pago;
        this.total = total;
    }
          
    
    public String getProducto() {
        return producto;
    }

    public int getCant() {
        return cant;
    }

    public double getcodigo() {
        return codigo;
    }

    public double getMetodo_pago() {
        return metodo_pago;
    }

    
    public double getTotal() {
        return total;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public void setcodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setMetodo_pago(double metodo_pago) {
        this.metodo_pago = metodo_pago;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
}
